package data.datasource.csv

import data.dataholder.LogisticsPackageRaw
import data.datasource.PackageDataSource
import data.exception.local.LocalDataException
import data.parser.PackageParser
import data.validation.LocalDataSourceValidator
import java.io.File

class CsvPackageDataSource(
    private val packageFile: File,
    private val packageParser: PackageParser,
    private val localDataSourceValidator: LocalDataSourceValidator
) : PackageDataSource {

    private val headerLineCount = 1

    override fun loadPackages(): List<LogisticsPackageRaw> {
        localDataSourceValidator.validate(packageFile)

        val packageRows = packageFile.readLines()

        if (packageRows.size <= headerLineCount) {
            throw LocalDataException(
                "CSV file contains no data rows: ${packageFile.name}"
            )
        }

        val dataRows = packageRows.drop(headerLineCount)

        return dataRows.mapNotNull { packageRow ->
            packageParser.parsePackageRow(packageRow)
        }
    }
}
