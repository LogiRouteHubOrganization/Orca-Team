package domain.usecase

import domain.model.Package
import domain.model.updateinput.WarehouseUpdateModel
import domain.repository.WarehouseRepository

class AssignPackageToCargoQueueUseCase(
    private val sortCargoQueue: SortingCargoQueueUseCase,
    private val warehouseRepository: WarehouseRepository
) {

    suspend operator fun invoke(logisticsPackage: Package) {
        val originWarehouse = logisticsPackage.originWarehouse

        originWarehouse.addPackage(logisticsPackage)

        sortCargoQueue(originWarehouse)

        val warehouseUpdateModel = WarehouseUpdateModel()

        warehouseRepository.update(originWarehouse.id, warehouseUpdateModel)
    }
}
